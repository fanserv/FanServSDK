//
//  FanServerBannerCustomEvent.m
//  MoPubSampleApp
//
//  Created by Karol Kempa on 09.01.2015.
//  Copyright (c) 2015 MoPub. All rights reserved.
//

#import "FanServerBannerCustomEvent.h"
#import "MPLogging.h"
#import <FanServerFramework/FanServerAdView.h>
#import <FanServerFramework/FanServerMRAIDView.h>

@implementation MPInstanceProvider (FanServerBanners)

- (FanServerAdView *) buildFanServerRequestWithAppID:(NSString *)appId window:(UIWindow *)window delegate:(id<FanServerAdServerAdsDelegate>)delegate {
    FanServerAdView *adView = [[FanServerAdView alloc] init];
    
    [FanServer setAdsDelegate:delegate];
    [FanServer setAppid:appId];
    [FanServer setWindow:window];
    return adView;
}

@end

@interface FanServerBannerCustomEvent()<FanServerAdServerAdsDelegate>

@property (strong, nonatomic) FanServerAdView *adView;

@end

@implementation FanServerBannerCustomEvent

- (void)requestAdWithSize:(CGSize)size customEventInfo:(NSDictionary *)info {
    
    if(size.height != 50 || (size.width != 300 && size.width != 320)) {
        MPLogError(@"Banner size not valid");
        [self.delegate bannerCustomEvent:self didFailToLoadAdWithError:nil];
        return;
    }
    if(![info objectForKey:@"appID"]) {
        MPLogError(@"Required appID");
        [self.delegate bannerCustomEvent:self didFailToLoadAdWithError:nil];
        return;
    }
    if(![info objectForKey:@"server"]) {
        MPLogError(@"Required server address");
        [self.delegate bannerCustomEvent:self didFailToLoadAdWithError:nil];
        return;
    }
    
    if([[info objectForKey:@"server"] isEqualToNumber:@(FanServerQa)]) {
        [FanServer setServerAddress:FanServerQa];
    } else {
        [FanServer setServerAddress:FanServerProd];
    }
    if([info objectForKey:@"keywords"]) {
        [FanServer setKeywords:[info objectForKey:@"keywords"]];
    }
    
    MPLogInfo(@"Requesting FanServer banner");
    
    self.adView = [[MPInstanceProvider sharedProvider] buildFanServerRequestWithAppID:[info objectForKey:@"appID"] window:[[UIApplication sharedApplication].delegate window] delegate:self];
    FanServerAdSize adSize = size.width > 300 ? FanServerAdSizeBanner320x50 : FanServerAdSizeBanner300x50;
    [FanServer setAdType:FanServerAdTypeBanner adsize:adSize deviceType:FanServerDeviceTypeMobile];
    [FanServer requestAdData];
}

#pragma mark -
#pragma mark FanServerSDKDelegate
- (void) fanServerShouldCloseBannerAd:(FanServerAdView *)adView {
    [self.delegate bannerCustomEventDidFinishAction:self];
    NSLog(@"fanServerBannerShouldClose");
}
- (void) fanServerAdDidFail {
    [self.delegate bannerCustomEvent:self didFailToLoadAdWithError:nil];
}
- (void) fanServerRequestDidFail {
    [self.delegate bannerCustomEvent:self didFailToLoadAdWithError:nil];
}
- (void) fanServerAdTapped {
    if(self.delegate && [self.delegate respondsToSelector:@selector(trackClick)]) {
        [self.delegate trackClick];
    }
    [self.delegate bannerCustomEventWillBeginAction:self];
}
- (void) fanServerMRAIDViewAdLoaded:(FanServerMRAIDView *)adView {
    [self.delegate bannerCustomEvent:self didLoadAd:adView];
}

- (void) fanServerDidLoadBannerAd:(FanServerAdView *)adView {
    [self.delegate bannerCustomEvent:self didLoadAd:adView];
}
- (void) fanServerDidFailDisplay {
    [self.delegate bannerCustomEvent:self didFailToLoadAdWithError:nil];
}

@end
