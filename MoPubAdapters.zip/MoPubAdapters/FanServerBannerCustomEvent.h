//
//  FanServerBannerCustomEvent.h
//  MoPubSampleApp
//
//  Created by Karol Kempa on 09.01.2015.
//  Copyright (c) 2015 MoPub. All rights reserved.
//

#import "MPBannerCustomEvent.h"
#import "MPInstanceProvider.h"
#import <FanServer.h>
//#import <FanServerFramework/FanServer.h>

@interface FanServerBannerCustomEvent : MPBannerCustomEvent

@end
