//
//  FanServerInterstitialCustomEvent.m
//  MoPubTest
//
//  Created by Karol Kempa on 09.01.2015.
//  Copyright (c) 2015 i2asolutions. All rights reserved.
//

#import "FanServerInterstitialCustomEvent.h"
#import "MPLogging.h"
#import <FanServerFramework/FanServerMRAIDView.h>

@implementation MPInstanceProvider (FanServerInterstitials)

- (FanServerAdView *) buildFanServerRequestWithAppID:(NSString *)appId window:(UIWindow *)window delegate:(id<FanServerAdServerAdsDelegate>)delegate {
    FanServerAdView *adView = [[FanServerAdView alloc] init];
    [FanServer setAdsDelegate:delegate];
    [FanServer setAppid:appId];
    [FanServer setWindow:window];
    return adView;
}

@end

@interface FanServerInterstitialCustomEvent()<FanServerAdServerAdsDelegate, FanServerMRAIDInterstitialDelegate>

@property (strong, nonatomic) FanServerAdView *adView;
@property (strong, nonatomic) FanServerMRAIDView *mraidView;

@end

@implementation FanServerInterstitialCustomEvent

- (void) requestInterstitialWithCustomEventInfo:(NSDictionary *)info {
    
    if(![info objectForKey:@"appID"]) {
        MPLogError(@"Required appID");
        [self.delegate interstitialCustomEvent:self didFailToLoadAdWithError:nil];
        return;
    }
    
    if([[info objectForKey:@"server"] isEqualToNumber:@(FanServerQa)]) {
        [FanServer setServerAddress:FanServerQa];
    } else {
        [FanServer setServerAddress:FanServerProd];
    }

    
    if([info objectForKey:@"keywords"]) {
        [FanServer setKeywords:[info objectForKey:@"keywords"]];
    }

    MPLogInfo(@"Requesting FanServer interstitial");
    
    self.adView = [[MPInstanceProvider sharedProvider] buildFanServerRequestWithAppID:[info objectForKey:@"appID"] window:[[UIApplication sharedApplication].delegate window] delegate:self];
    [FanServer preloadAds:FanServerAdTypeInterstitial adsize:FanServerAdSizePhoneInterstitial deviceType:FanServerDeviceTypeMobile];
};

- (void) dealloc {
    self.adView = nil;
    self.mraidView = nil;
}

- (void) showInterstitialFromRootViewController:(UIViewController *)rootViewController {
    if(self.mraidView) {
        [rootViewController.view addSubview:self.mraidView];
    } else if(self.adView) {
        [rootViewController.view addSubview:self.adView];
    }
}

#pragma mark -
#pragma mark FanServerSDKDelegate

- (void)fanServerShouldReturnAdView:(FanServerAdView *)view {
    NSLog(@"Should return adView: %@", view);
}

- (void) fanServerMRAIDInterstitialAdLoaded:(FanServerMRAIDView *)adView {
    [self.delegate interstitialCustomEvent:self didLoadAd:adView];
    self.mraidView = adView;
}

- (void) fanServerShouldCloseInterstitialAd:(FanServerAdView *)adView {
    [adView removeFromSuperview];
    adView = nil;
    [self.delegate interstitialCustomEventWillDisappear:self];
}
- (void) fanServerInterstitialDidAppear {
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEventDidAppear:)]) {
        [self.delegate interstitialCustomEventDidAppear:self];
    }
}
- (void) fanServerInterstitialDidClose {
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEventDidDisappear:)]) {
        [self.delegate interstitialCustomEventDidDisappear:self];
    }
}
- (void) fanServerAdDidFail {
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEvent:didFailToLoadAdWithError:)]) {
        [self.delegate interstitialCustomEvent:self didFailToLoadAdWithError:nil];
    }
}
- (void) fanServerRequestDidFail {
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEvent:didFailToLoadAdWithError:)]) {
        [self.delegate interstitialCustomEvent:self didFailToLoadAdWithError:nil];
    }
}
- (void) fanServerAdTapped {
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEventDidReceiveTapEvent:)]) {
        [self.delegate interstitialCustomEventDidReceiveTapEvent:self];
    }
    if ([self.delegate respondsToSelector:@selector(trackClick)]) {
        [self.delegate trackClick];
    }
}
- (void) fanServerDidLoadInterstitialAd:(FanServerAdView *)adView {
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEvent:didLoadAd:)]) {
        [self.delegate interstitialCustomEvent:self didLoadAd:adView];
    }
}
- (void) fanServerDidFailDisplay {
    if ([self.delegate respondsToSelector:@selector(interstitialCustomEvent:didFailToLoadAdWithError:)]) {
        [self.delegate interstitialCustomEvent:self didFailToLoadAdWithError:nil];
    }
}

@end