//
//  FanServerInterstitialCustomEvent.h
//  MoPubTest
//
//  Created by Karol Kempa on 09.01.2015.
//  Copyright (c) 2015 i2asolutions. All rights reserved.
//

#import "MPInterstitialCustomEvent.h"
#import "MPInstanceProvider.h"
#import <FanServerFramework/FanServer.h>
#import <FanServerFramework/FanServerAdView.h>

@interface FanServerInterstitialCustomEvent : MPInterstitialCustomEvent

@end

@interface MPInstanceProvider (FanServerInterstitials)

- (FanServerAdView *) buildFanServerRequestWithAppID:(NSString *)appId window:(UIWindow *)window delegate:(id<FanServerAdServerAdsDelegate>)delegate;

@end

