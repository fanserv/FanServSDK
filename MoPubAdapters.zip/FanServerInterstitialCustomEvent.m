//
//  FanServerInterstitialCustomEvent.m
//  MoPubTest
//
//  Created by Karol Kempa on 09.01.2015.
//  Copyright (c) 2015 i2asolutions. All rights reserved.
//

#import "FanServerInterstitialCustomEvent.h"
#import "MPLogging.h"

@implementation MPInstanceProvider (FanServerInterstitials)

- (void)prepareFanServerRequestWithAppID:(NSString *)appId serverAddress:(FanServerAddress)serverAddress delegate:(id<FSDisplayManagerDelegate>)delegate {
    [FanServer setupWithAppID:appId serverAddress:serverAddress];
    [FanServer setDisplayingDelegate:delegate];
}
@end

@interface FanServerInterstitialCustomEvent() <FSDisplayManagerDelegate>

@property (nonatomic, strong) UIView *interstitialAd;

@end

@implementation FanServerInterstitialCustomEvent

- (void) requestInterstitialWithCustomEventInfo:(NSDictionary *)info {
    if(![info objectForKey:@"appID"]) {
        MPLogError(@"Required appID");
        [self.delegate interstitialCustomEvent:self didFailToLoadAdWithError:nil];
        return;
    }
    
    NSInteger serverAddress = FanServerProd;
    if([[info objectForKey:@"server"] isEqualToNumber:@(FanServerQa)]) {
        serverAddress = FanServerQa;
    } else if ([[info objectForKey:@"server"] isEqualToNumber:@(FanServerDev)]) {
        serverAddress = FanServerDev;
    }
    
    if([info objectForKey:@"keywords"]) {
        [FanServer setKeywords:[info objectForKey:@"keywords"]];
    }

    MPLogInfo(@"Requesting FanServer interstitial");
    
    [[MPInstanceProvider sharedProvider] prepareFanServerRequestWithAppID:info[@"appID"]
                                                            serverAddress:serverAddress
                                                                 delegate:self];
    
    FanServerAdSize adSize = [UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad ? FanServerAdSizeTabletInterstitial : FanServerAdSizePhoneInterstitial;
    [FanServer createAdViewWithSize:adSize
                            success:^(UIView *advertisementView) {
                                self.interstitialAd = advertisementView;
                                if (self.delegate && [self.delegate respondsToSelector:@selector(interstitialCustomEvent:didLoadAd:)]) {
                                    [self.delegate interstitialCustomEvent:self didLoadAd:advertisementView];
                                }
                            } failure:^(NSError *error) {
                                if (self.delegate && [self.delegate respondsToSelector:@selector(interstitialCustomEvent:didFailToLoadAdWithError:)]) {
                                    [self.delegate interstitialCustomEvent:self didFailToLoadAdWithError:error];
                                }
                            }];

};

- (void) showInterstitialFromRootViewController:(UIViewController *)rootViewController {
    if (self.interstitialAd) {
        [rootViewController.view addSubview:self.interstitialAd];
    }
}

#pragma mark -
#pragma mark FSDisplayManagerDelegate

- (void)displayManagerDidShowView:(UIView *)view {
    if(self.delegate && [self.delegate respondsToSelector:@selector(interstitialCustomEventDidAppear:)]) {
        [self.delegate interstitialCustomEventDidAppear:self];
    }
    if(self.delegate && [self.delegate respondsToSelector:@selector(trackImpression)]) {
        [self.delegate trackImpression];
    }
}

- (void)displayManagerDidRecognizedTapOnView:(UIView *)view {
    if (self.delegate && [self.delegate respondsToSelector:@selector(interstitialCustomEventDidReceiveTapEvent:)]) {
        [self.delegate interstitialCustomEventDidReceiveTapEvent:self];
    }
    if (self.delegate && [self.delegate respondsToSelector:@selector(trackClick)]) {
        [self.delegate trackClick];
    }
}

- (void)displayManagerViewWillCloseView:(UIView *)view {
    if (self.delegate && [self.delegate respondsToSelector:@selector(interstitialCustomEventWillDisappear:)]) {
        [self.delegate interstitialCustomEventWillDisappear:self];
    }
}

- (void)displayManagerDidCloseView:(UIView *)view {
    if (self.delegate && [self.delegate respondsToSelector:@selector(interstitialCustomEventDidDisappear:)]) {
        [self.delegate interstitialCustomEventDidDisappear:self];
    }
}


@end