//
//  FanServerBannerCustomEvent.m
//  MoPubSampleApp
//
//  Created by Karol Kempa on 09.01.2015.
//  Copyright (c) 2015 MoPub. All rights reserved.
//

#import "FanServerBannerCustomEvent.h"
#import "MPLogging.h"

@implementation MPInstanceProvider (FanServerBanners)

- (void)prepareFanServerRequestWithAppID:(NSString *)appId serverAddress:(FanServerAddress)serverAddress delegate:(id<FSDisplayManagerDelegate>)delegate {
    [FanServer setupWithAppID:appId serverAddress:serverAddress];
    [FanServer setDisplayingDelegate:delegate];
}

@end

@interface FanServerBannerCustomEvent() <FSDisplayManagerDelegate>

@end

@implementation FanServerBannerCustomEvent

- (void)requestAdWithSize:(CGSize)size customEventInfo:(NSDictionary *)info {
    
    if(size.height != 50 || (size.width != 300 && size.width != 320)) {
        MPLogError(@"Banner size not valid");
        [self.delegate bannerCustomEvent:self didFailToLoadAdWithError:nil];
        return;
    }
    if(![info objectForKey:@"appID"]) {
        MPLogError(@"Required appID");
        [self.delegate bannerCustomEvent:self didFailToLoadAdWithError:nil];
        return;
    }
    if(![info objectForKey:@"server"]) {
        MPLogError(@"Required server address");
        [self.delegate bannerCustomEvent:self didFailToLoadAdWithError:nil];
        return;
    }
    NSInteger serverAddress = FanServerProd;
    if([[info objectForKey:@"server"] isEqualToNumber:@(FanServerQa)]) {
        serverAddress = FanServerQa;
    } else if ([[info objectForKey:@"server"] isEqualToNumber:@(FanServerDev)]) {
        serverAddress = FanServerDev;
    }
    
    if([info objectForKey:@"keywords"]) {
        [FanServer setKeywords:[info objectForKey:@"keywords"]];
    }
    
    MPLogInfo(@"Requesting FanServer banner");
    [[MPInstanceProvider sharedProvider] prepareFanServerRequestWithAppID:info[@"appID"]
                                                            serverAddress:serverAddress
                                                                 delegate:self];
    
    FanServerAdSize adSize = size.width > 300 ? FanServerAdSizeBanner320x50 : FanServerAdSizeBanner300x50;
    [FanServer createAdViewWithSize:adSize
                            success:^(UIView *advertisementView) {
                                if (self.delegate && [self.delegate respondsToSelector:@selector(bannerCustomEvent:didLoadAd:)]) {
                                    [self.delegate bannerCustomEvent:self didLoadAd:advertisementView];
                                }
                            } failure:^(NSError *error) {
                                if (self.delegate && [self.delegate respondsToSelector:@selector(bannerCustomEvent:didFailToLoadAdWithError:)]) {
                                    [self.delegate bannerCustomEvent:self didFailToLoadAdWithError:error];
                                }
                            }];
}

#pragma mark -
#pragma mark FSDisplayManagerDelegate

- (void)displayManagerDidShowView:(UIView *)view {
    if(self.delegate && [self.delegate respondsToSelector:@selector(trackImpression)]) {
        [self.delegate trackImpression];
    }
}

- (void)displayManagerDidRecognizedTapOnView:(UIView *)view {
    if(self.delegate && [self.delegate respondsToSelector:@selector(trackClick)]) {
        [self.delegate trackClick];
    }
    if(self.delegate && [self.delegate respondsToSelector:@selector(bannerCustomEventWillBeginAction:)]) {
        [self.delegate bannerCustomEventWillBeginAction:self];
    }
}

- (void)displayManagerViewWillCloseView:(UIView *)view {
    if(self.delegate && [self.delegate respondsToSelector:@selector(bannerCustomEventDidFinishAction:)]) {
        [self.delegate bannerCustomEventDidFinishAction:self];
    }
}

@end
